package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Main {

    private static List<Student1> studentList = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        do {
            menu();
        } while (true);
    }

    public static void menu() {
        System.out.println("1. Add Students");
        System.out.println("2. Update Students");
        System.out.println("3. Delete Student");
        System.out.println("4. Search Students");
        System.out.println("5. Sort Students");
        System.out.println("6. Generate Random Students");
        System.out.println("7. Exit");
        System.out.print("Choose an option: ");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                addStudent();
                break;
            case 2:
                updateStudent();
                break;
            case 3:
                deleteStudent();
                break;
            case 4:
                searchStudent();
                break;
            case 5:
                sortStudents();
                break;
            case 6:
                generateRandomStudents();
                break;
            case 7:
                System.exit(0);
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    // Thêm sinh viên
    public static void addStudent() {
        System.out.print("Enter student name: ");
        String name = scanner.nextLine();
        System.out.print("Enter student score: ");
        double score = scanner.nextDouble();
        int id = studentList.size() + 1; // Tạo ID đơn giản

        Student1 student = new Student1(id, name, "090" + String.format("%08d", new Random().nextInt(100000000)), score);
        studentList.add(student);
        System.out.println("Student added successfully!");
        printStudentList();
    }

    // Cập nhật thông tin sinh viên
    public static void updateStudent() {
        System.out.print("Enter student ID to update: ");
        try {
            int id = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            boolean found = false;
            for (Student1 student : studentList) {
                if (student.getId() == id) {
                    found = true;
                    System.out.print("Enter new name: ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter new score: ");
                    double newScore = scanner.nextDouble();
                    studentList.set(studentList.indexOf(student), new Student1(id, newName, student.getContactNumber(), newScore));
                    System.out.println("Student updated successfully!");
                    printStudentList();
                    return;
                }
            }
            if (!found) {
                System.out.println("Student not found.");
            }
        } catch (Exception e) {
            System.out.println("Invalid input. Please enter a valid student ID.");
            scanner.nextLine(); // Clear the invalid input
        }
    }

    // Xóa sinh viên
    public static void deleteStudent() {
        System.out.print("Enter student ID to delete: ");
        try {
            int id = scanner.nextInt();

            boolean found = false;
            for (Student1 student : studentList) {
                if (student.getId() == id) {
                    found = true;
                    studentList.remove(student);
                    System.out.println("Student deleted successfully!");
                    printStudentList();
                    return;
                }
            }
            if (!found) {
                System.out.println("Student not found.");
            }
        } catch (Exception e) {
            System.out.println("Invalid input. Please enter a valid student ID.");
            scanner.nextLine(); // Clear the invalid input
        }
    }

    // Tìm kiếm sinh viên
    public static void searchStudent() {
        System.out.print("Enter student name or ID to search: ");
        String input = scanner.nextLine();

        try {
            int id = Integer.parseInt(input);
            for (Student1 student : studentList) {
                if (student.getId() == id) {
                    System.out.println("Student found: " + student);
                    return;
                }
            }
        } catch (NumberFormatException e) {
            for (Student1 student : studentList) {
                if (student.getName().equalsIgnoreCase(input)) {
                    System.out.println("Student found: " + student);
                    return;
                }
            }
        }
        System.out.println("Student not found.");
    }

    // Sắp xếp sinh viên và đo thời gian thực thi
    public static void sortStudents() {
        System.out.println("Sort by: 1. Score 2. Name");
        int sortChoice = scanner.nextInt();

        // Sắp xếp bằng QuickSort
        long startTime = System.nanoTime();
        if (sortChoice == 1) {
            QuickSort.quickSort(studentList.toArray(new Student1[0]), 0, studentList.size() - 1);
            long endTime = System.nanoTime();
            long quickSortTime = endTime - startTime;
            System.out.println("QuickSort time: " + quickSortTime + " nanoseconds");
        } else if (sortChoice == 2) {
            studentList.sort((s1, s2) -> s1.getName().compareTo(s2.getName()));
            System.out.println("Students sorted by name using built-in sort.");
        }

        // Sắp xếp bằng BubbleSort
        startTime = System.nanoTime();
        if (sortChoice == 1) {
            BubbleSort.sort(studentList.toArray(new Student1[0])); // Sử dụng BubbleSort từ class BubbleSort
            long endTime = System.nanoTime();
            long bubbleSortTime = endTime - startTime;
            System.out.println("BubbleSort time: " + bubbleSortTime + " nanoseconds");
        }

        printStudentList();
    }

    // Tạo danh sách sinh viên ngẫu nhiên
    public static void generateRandomStudents() {
        System.out.print("Enter the number of random students to generate: ");
        try {
            int n = scanner.nextInt();
            while (n <= 0) {
                System.out.print("Enter a positive integer: ");
                n = scanner.nextInt();
            }

            List<Student1> randomStudents = generateFakeStudents(n);
            studentList.addAll(randomStudents);
            System.out.println(n + " random students added successfully!");
            printStudentList();
        } catch (Exception e) {
            System.out.println("Invalid input. Please enter a valid number.");
            scanner.nextLine(); // Clear the invalid input
        }
    }

    // In danh sách sinh viên
    public static void printStudentList() {
        System.out.println("Current Student List:");
        for (Student1 student : studentList) {
            System.out.println(student);
        }
    }

    //Tạo ngẫu nhiên sinh viên
    public static List<Student1> generateFakeStudents(int count) {
        List<Student1> students = new ArrayList<>();
        Random random = new Random();

        // Tính toán ID bắt đầu từ ID tiếp theo sau danh sách hiện tại
        int startId = studentList.size() + 1;

        // Tạo ngẫu nhiên sinh viên
        for (int i = 0; i < count; i++) {
            int id = startId + i; // ID tăng dần
            String name = "Student " + id;
            String contactNumber = "090" + String.format("%08d", random.nextInt(100000000));
            double marks = 5 + random.nextDouble() * 5; // Điểm ngẫu nhiên từ 5.0 đến 10.0

            Student1 student = new Student1(id, name, contactNumber, marks);
            students.add(student);
        }

        return students;
    }
}
