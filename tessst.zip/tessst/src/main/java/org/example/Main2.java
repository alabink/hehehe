package org.example;

public class Main2 {
    public static void main(String[] args) {
        // Array-based stack
        ArrayStack arrayStack = new ArrayStack(5);
        arrayStack.push(10);
        arrayStack.push(20);
        arrayStack.push(30);

        System.out.println("Array-based stack:");
        System.out.println("Top element: " + arrayStack.peek());

        arrayStack.pop();
        System.out.println("After popping one element: " + arrayStack.peek());

        // Linked-list-based stack
        LinkedListStack linkedListStack = new LinkedListStack();
        linkedListStack.push(10);
        linkedListStack.push(20);
        linkedListStack.push(30);

        System.out.println("\nLinked-list-based stack:");
        System.out.println("Top element: " + linkedListStack.peek());

        linkedListStack.pop();
        System.out.println("After popping one element: " + linkedListStack.peek());
    }
}