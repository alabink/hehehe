package org.example;

public class MainStudent {
    public static void main(String[] args) {
        // Create a new Student object
        Student student = new Student("Duong Bao Long", "BH02012", 3.5);

        // Display the student's details
        System.out.println("Student Name: " + student.getName());
        System.out.println("Student ID: " + student.getStudentId());
        System.out.println("Student GPA: " + student.getGpa());

        // Attempt to set a new GPA
        student.setGpa(3.8); // Valid GPA
        System.out.println("Updated GPA: " + student.getGpa());

        student.setGpa(4.5); // Invalid GPA
    }
}
