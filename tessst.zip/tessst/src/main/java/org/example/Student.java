package org.example;

public class Student {
    // Private fields to store student details
    private String name;
    private String studentId;
    private double gpa;

    // Constructor to initialize the student
    public Student(String name, String studentId, double gpa) {
        this.name = name;
        this.studentId = studentId;
        this.setGpa(gpa); // Using setter to ensure valid GPA initialization
    }

    // Public method to get the student's name
    public String getName() {
        return name;
    }

    // Public method to set the student's name
    public void setName(String name) {
        this.name = name;
    }

    // Public method to get the student's ID
    public String getStudentId() {
        return studentId;
    }

    // Public method to get the student's GPA
    public double getGpa() {
        return gpa;
    }

    // Public method to set the student's GPA
    public void setGpa(double gpa) {
        if (gpa >= 0.0 && gpa <= 4.0) {
            this.gpa = gpa;
        } else {
            System.out.println("Invalid GPA. Please enter a GPA between 0.0 and 4.0.");
        }
    }
}

