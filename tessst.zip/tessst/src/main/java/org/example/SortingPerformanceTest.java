package org.example;
import java.util.Arrays;

public class SortingPerformanceTest {
    public static void main(String[] args) {
        int[] bubbleSortArray = {64, 34, 25, 12, 22, 11, 90};
        int[] quickSortArray = {64, 34, 25, 12, 22, 11, 90};

        // Timing Bubble Sort
        long startTime = System.nanoTime();
        BubbleSort.bubbleSort(bubbleSortArray);
        long endTime = System.nanoTime();
        System.out.println("Bubble Sort Result: " + Arrays.toString(bubbleSortArray));
        System.out.println("Bubble Sort Time: " + (endTime - startTime) + " ns");

        // Timing Quick Sort
        startTime = System.nanoTime();
        QuickSort.quickSort(quickSortArray, 0, quickSortArray.length - 1);
        endTime = System.nanoTime();
        System.out.println("Quick Sort Result: " + Arrays.toString(quickSortArray));
        System.out.println("Quick Sort Time: " + (endTime - startTime) + " ns");
    }
}

