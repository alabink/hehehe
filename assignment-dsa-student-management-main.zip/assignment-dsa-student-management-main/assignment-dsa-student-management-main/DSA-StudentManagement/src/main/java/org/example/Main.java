package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        StudentStack studentStack = new StudentStack(); // Stack-based manager
        Scanner scanner = new Scanner(System.in);

        // Pre-added students
        studentStack.push(new Student(1, "Dương Bảo Long", 85));  // Very Good
        studentStack.push(new Student(2, "Ngô Tùng Lâm", 92));    // Excellent
        studentStack.push(new Student(3, "Nguyễn Bảo Khánh", 60)); // Medium
        studentStack.push(new Student(4, "Trần Tiến Đạt", 45));   // Fail
        studentStack.push(new Student(5, "Phạm Tuấn Anh", 70));     // Good

        while (true) {
            System.out.println("\nStudent Stack Management:");
            System.out.println("1. Add Student to Stack");
            System.out.println("2. Pop Student from Stack");
            System.out.println("3. Peek at Top Student");
            System.out.println("4. Display All Students in Stack");
            System.out.println("5. Search Student by ID");
            System.out.println("6. Update Student by ID");
            System.out.println("7. Delete Student by ID");
            System.out.println("8. Sort Students by Rank");
            System.out.println("9. Check if Stack is Empty");
            System.out.println("10. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Student ID: ");
                    int id = scanner.nextInt();
                    System.out.print("Enter Student Name: ");
                    scanner.nextLine(); // consume newline
                    String name = scanner.nextLine();
                    System.out.print("Enter Student Marks: ");
                    double marks = scanner.nextDouble();
                    studentStack.push(new Student(id, name, marks));
                    break;
                case 2:
                    studentStack.pop();
                    break;
                case 3:
                    Student topStudent = studentStack.peek();
                    if (topStudent != null) {
                        System.out.println("Top Student: " + topStudent);
                    }
                    break;
                case 4:
                    studentStack.displayStudents();
                    break;
                case 5:
                    System.out.print("Enter Student ID to Search: ");
                    int searchId = scanner.nextInt();
                    Student foundStudent = studentStack.searchById(searchId);
                    if (foundStudent != null) {
                        System.out.println("Student Found: " + foundStudent);
                    } else {
                        System.out.println("Student with ID " + searchId + " not found.");
                    }
                    break;
                case 6:
                    System.out.print("Enter Student ID to Update: ");
                    int updateId = scanner.nextInt();
                    System.out.print("Enter New Name: ");
                    scanner.nextLine(); // consume newline
                    String newName = scanner.nextLine();
                    System.out.print("Enter New Marks: ");
                    double newMarks = scanner.nextDouble();
                    boolean updated = studentStack.updateStudentById(updateId, newName, newMarks);
                    if (updated) {
                        System.out.println("Student with ID " + updateId + " updated successfully.");
                    } else {
                        System.out.println("Student with ID " + updateId + " not found.");
                    }
                    break;
                case 7:
                    System.out.print("Enter Student ID to Delete: ");
                    int deleteId = scanner.nextInt();
                    boolean deleted = studentStack.deleteById(deleteId);
                    if (deleted) {
                        System.out.println("Student with ID " + deleteId + " deleted successfully.");
                    } else {
                        System.out.println("Student with ID " + deleteId + " not found.");
                    }
                    break;
                case 8:
                    studentStack.sortByRank();
                    break;
                case 9:
                    if (studentStack.isEmpty()) {
                        System.out.println("Stack is empty.");
                    } else {
                        System.out.println("Stack is not empty. Size: " + studentStack.size());
                    }
                    break;
                case 10:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}