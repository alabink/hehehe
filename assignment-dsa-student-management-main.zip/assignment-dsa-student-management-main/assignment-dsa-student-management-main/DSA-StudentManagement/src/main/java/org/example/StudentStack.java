package org.example;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class StudentStack {
    private Node top; // Top of the stack
    private int size; // To keep track of the number of elements

    // Constructor
    public StudentStack() {
        top = null; // Stack is initially empty
        size = 0;   // Initial size is 0
    }

    // Push a student onto the stack
    public void push(Student student) {
        Node newNode = new Node(student);
        newNode.next = top; // Point new node to the previous top
        top = newNode;      // Update top to be the new node
        size++;
        System.out.println("Inserted: " + student);
    }

    // Pop a student from the stack
    public Student pop() {
        if (isEmpty()) {
            System.out.println("Stack Underflow! No students to remove.");
            return null;
        }
        Student poppedStudent = top.student; // Get the student from the top node
        top = top.next;                     // Move top to the next node
        size--;
        System.out.println("Popped: " + poppedStudent);
        return poppedStudent;
    }

    // Peek at the top student without removing
    public Student peek() {
        if (isEmpty()) {
            System.out.println("Stack is empty!");
            return null;
        }
        return top.student; // Return the student at the top node
    }

    // Check if the stack is empty
    public boolean isEmpty() {
        return top == null; // Stack is empty if top is null
    }

    // Get the size of the stack
    public int size() {
        return size; // Return current size of the stack
    }

    // Display all students in the stack
    public void displayStudents() {
        if (isEmpty()) {
            System.out.println("No students in the stack.");
            return;
        }

        System.out.println("Students in Stack:");
        Node current = top;  // Start from the top node
        while (current != null) {
            System.out.println(current.student);
            current = current.next; // Move to the next node
        }
    }

    // Search for a student by ID
    public Student searchById(int id) {
        Node current = top;
        while (current != null) {
            if (current.student.getId() == id) {
                return current.student; // Found the student with matching ID
            }
            current = current.next; // Move to the next node
        }
        return null; // Student not found
    }

    // Update a student's information by ID
    public boolean updateStudentById(int id, String newName, double newMarks) {
        Node current = top;
        while (current != null) {
            if (current.student.getId() == id) {
                current.student.setMarks(newMarks);
                // Assuming we want to update the name as well
                current.student = new Student(id, newName, newMarks);
                return true; // Student found and updated
            }
            current = current.next;
        }
        return false; // Student not found
    }

    // Delete a student by ID
    public boolean deleteById(int id) {
        if (isEmpty()) {
            System.out.println("Stack is empty. No students to delete.");
            return false;
        }

        // Special case if the student to be deleted is at the top
        if (top.student.getId() == id) {
            pop();
            return true;
        }

        Node current = top;
        Node prev = null;
        while (current != null) {
            if (current.student.getId() == id) {
                if (prev != null) {
                    prev.next = current.next; // Skip over the node to delete it
                }
                size--;
                return true;
            }
            prev = current;
            current = current.next;
        }
        return false; // Student not found
    }

    // Sort students by their rank (marks) in descending order
    public void sortByRank() {
        if (isEmpty()) {
            System.out.println("No students in the stack.");
            return;
        }

        // Convert stack to ArrayList for easier sorting
        ArrayList<Student> studentList = new ArrayList<>();
        Node current = top;
        while (current != null) {
            studentList.add(current.student);
            current = current.next;
        }

        // Sort the list by marks (descending order)
        Collections.sort(studentList, new Comparator<Student>() {
            @Override
            public int compare(Student s1, Student s2) {
                return Double.compare(s2.getMarks(), s1.getMarks());
            }
        });

        // Rebuild the stack from the sorted list
        top = null;
        size = 0;
        for (Student student : studentList) {
            push(student);
        }

        System.out.println("Students sorted by rank.");
        displayStudents(); // Display the sorted students
    }
}
